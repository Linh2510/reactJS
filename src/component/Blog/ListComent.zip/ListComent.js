import React, { Component } from 'react'

export default class ListComent extends Component {
    constructor(props) {
        super(props);
        this.state = ({
          id_comment :''
        })
        this.inComment = this.inComment.bind(this)
        this.handleReply = this.handleReply.bind(this)
    }
    handleReply(e){
      let comment = this.props.comment
      let id = e.target.id
      // this.setState ({
      //   id_comment : id
      // })
      // console.log(id)
    };
    inComment(){
      let comment = this.props.comment
      console.log(comment)
      return Object.keys(comment).map(function(key,index){
          return (
            <li className="media" key={key} id={key}>
                    <a className="pull-left" href="#">
                      <img className="media-object" src={"http://localhost:8080/api-laravel/laravel/public/upload/user/avatar/"+ comment[key]['image_user']}  alt="" />
                    </a>
                    <div className="media-body">
                      <ul className="sinlge-post-meta">
                        <li><i className="fa fa-user" />{comment[key]['name_user']}</li>
                        <li><i className="fa fa-clock-o" /> 1:33 pm</li>
                        <li><i className="fa fa-calendar" /> DEC 5, 2013</li>
                      </ul>
                    <p>{comment[key]['comment']}</p>
                    <a className="btn btn-primary" href="#rep" onClick={this.handleReply} id={key} ><i className="fa fa-reply" />Replay</a>
                  </div>
            </li> 
          )
      })
      
    }
    render() {
        return (
            <div>
                <div className="response-area">
                <h2>3 RESPONSES</h2>
                 <ul className="media-list">
                    {this.inComment()}
                 </ul>					 
              </div>
            </div>
        )
    }
}

